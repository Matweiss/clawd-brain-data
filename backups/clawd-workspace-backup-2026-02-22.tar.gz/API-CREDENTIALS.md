# API CREDENTIALS & ACCESS

**SECURITY NOTE:** This file contains sensitive credentials. Never share publicly.

---

## 🔑 **Google Workspace**

**OAuth Credentials:**
- **Client ID:** `391258212025-nafc7rponmj6i0ot2326j8ontcete0gn.apps.googleusercontent.com`
- **Client Secret:** `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`
- **Refresh Token:** `1//05Lhc3WteX-RMCgYIARAAGAUSNwF-L9IrFoxKput3tONdV4ymyWhdUG2_KqDjIJPd-Hu90H2iDDu7T-lCu2PGTif4XnrIR9Dgewc`

**Files:**
- Token: `/data/.openclaw/google-token.json`
- Credentials: `/data/.openclaw/google-credentials.json`
- Refresh Script: `/data/.openclaw/workspace/scripts/google-refresh-token.sh`

**Scopes:**
- `https://www.googleapis.com/auth/calendar`
- `https://www.googleapis.com/auth/calendar.events`
- `https://www.googleapis.com/auth/gmail.modify`
- `https://www.googleapis.com/auth/gmail.readonly`
- `https://www.googleapis.com/auth/gmail.compose`
- `https://www.googleapis.com/auth/spreadsheets`
- `https://www.googleapis.com/auth/documents`
- `https://www.googleapis.com/auth/presentations`
- `https://www.googleapis.com/auth/drive.file`
- `https://www.googleapis.com/auth/forms`

**Refresh Token Command:**
```bash
/data/.openclaw/workspace/scripts/google-refresh-token.sh
```

---

## 🔑 **HubSpot CRM**

**API Token:** `pat-na1-a249996e-eb7d-4184-841f-2759d28a8323`  
**Owner ID:** `728033696` (Mat's deals)  
**Base URL:** `https://api.hubapi.com`

**Stored In:** Gateway config (`env.vars.HUBSPOT_TOKEN`)

**Test Access:**
```bash
curl -H "Authorization: Bearer pat-na1-a249996e-eb7d-4184-841f-2759d28a8323" \
  "https://api.hubapi.com/crm/v3/objects/deals?limit=1"
```

---

## 🔑 **Avoma (Meeting Intelligence)**

**API Key:** `vh82rab620:2ci8lvop8u5duwc4u680`  
**Base URL:** `https://api.avoma.com/beta`

**Stored In:** Gateway config (`env.vars.AVOMA_API_KEY`)

**Test Access:**
```bash
curl -u "vh82rab620:2ci8lvop8u5duwc4u680" \
  "https://api.avoma.com/beta/conversations"
```

---

## 🔑 **ElevenLabs TTS**

**API Key:** `sk_20b35cd432e741e8f93429c78241d7d0d963810c22f27aaf`  
**Voice ID:** `IKne3meq5aSn9XLyUdCD` (Charlie - Deep, Confident, Energetic)  
**Model:** `eleven_turbo_v2_5`

**Script Location:** `/usr/local/lib/node_modules/openclaw/skills/elevenlabs/tts.sh`

**Test Command:**
```bash
/usr/local/lib/node_modules/openclaw/skills/elevenlabs/tts.sh "Test message"
```

---

## 🔑 **Grok (Whisper AI - Transcription)**

**API Key:** `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`

**Stored In:** Gateway config (`env.vars.GROK_API_KEY`)

---

## 🔑 **Telegram**

**Bot Token:** [REDACTED in gateway config]  
**Mat's Chat ID:** `8001393940`

**Stored In:** Gateway config (`channels.telegram.botToken`)

---

## 🔑 **Model APIs**

### **Kimi K2.5 (Moonshot AI) — FREE**
**API Key:** [REDACTED in gateway config]  
**Base URL:** `https://api.moonshot.cn/v1`  
**Model:** `moonshot-v1-128k`

### **MiniMax M2.5 — Low Cost**
**API Key:** [REDACTED in gateway config]  
**Base URL:** `https://api.minimax.chat/v1`  
**Model:** `MiniMax-Text-01`

---

## 📂 **File Locations**

- **Google Tokens:** `/data/.openclaw/google-token.json`
- **Google Credentials:** `/data/.openclaw/google-credentials.json`
- **Gateway Config:** `/data/.openclaw/openclaw.json`
- **Workspace:** `/data/.openclaw/workspace/`
- **Scripts:** `/data/.openclaw/workspace/scripts/`
- **Memory:** `/data/.openclaw/workspace/memory/`

---

## 🔄 **Recovery Instructions**

If session is lost, restore access by:

1. **Google APIs:** Run refresh script
   ```bash
   /data/.openclaw/workspace/scripts/google-refresh-token.sh
   ```

2. **Gateway Config:** Already persisted in `/data/.openclaw/openclaw.json`

3. **Skills:** Already installed in `/usr/local/lib/node_modules/openclaw/skills/`

4. **Memory:** Restore from GitHub (Clawd Brain syncs daily at 2am PST)

---

**Last Updated:** 2026-02-19  
**Saved:** `/data/.openclaw/workspace/API-CREDENTIALS.md`

---

## 🔑 **MiniMax M2.5 (Updated 2026-02-20)**

**API Key:** `sk-api-JvsDSAfGoVJSmEnOZQ6hduPCqqcWUWga6bcCgbfAws2onPmuzx7PQfT_SjVZ5Pgi80qQeRdyOIhsLWNRXYartUtEMFHUtxpj93eL5lypzu3U1IwY7Ffq2lw`  
**Base URL:** `https://api.minimax.chat/v1`  
**Model:** `MiniMax-Text-01` (M2.5 flagship)  
**Cost:** $0.30 input / $2.40 output per million tokens

**Test Status:** Key provided 2026-02-20, needs gateway update
**Stored In:** Gateway config (needs manual update)

**Test Command:**
```bash
curl -X POST https://api.minimax.chat/v1/text/chatcompletion \
  -H "Authorization: Bearer <key>" \
  -H "Content-Type: application/json" \
  -d '{"model": "MiniMax-Text-01", "messages": [{"role": "user", "content": "test"}]}'
```

---

## 🔑 **Perplexity API (New 2026-02-20)**

**API Key:** `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`  
**Base URL:** `https://api.perplexity.ai`  
**Usage:** Research Agent web searches  
**Cost:** FREE tier (5 requests/day) or $20/month (1000 requests)

**Test Command:**
```bash
curl -X POST https://api.perplexity.ai/chat/completions \
  -H "Authorization: Bearer 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" \
  -H "Content-Type: application/json" \
  -d '{"model": "sonar", "messages": [{"role": "user", "content": "test"}]}'
```

---

## 🏢 **ZoomInfo (Company Data Enrichment)**

**Source:** Mat's company subscription (Craftable)  
**Access:** Via HubSpot integration or browser extension  
**Rate Limit:** 3-5 manual lookups/day to avoid detection  
**Cache:** Store in Google Sheets for 90 days  

**Usage Strategy:**
- Primary: Check if ZoomInfo connected to HubSpot
- Secondary: Manual browser lookups (rate limited)
- Store: Company size, revenue, tech stack, funding

**Replaces:** Clearbit (Mat prefers ZoomInfo)

---

**Last Updated:** 2026-02-20 15:10 EST  
**New APIs Added:** MiniMax M2.5 (updated key), Perplexity, ZoomInfo notes
